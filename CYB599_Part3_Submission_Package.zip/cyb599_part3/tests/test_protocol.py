import unicodedata
import pytest
from src.psi_reference import encode_password, build_bins, psi_reference_check, polynomial_value, T

def test_known_breached_and_clean():
    corpus=['alpha-breach','beta-breach','gamma-breach']
    bins=build_bins(corpus,capacity=8)
    assert psi_reference_check('alpha-breach',bins)
    assert not psi_reference_check('clean-password',bins)

def test_nfc_normalization():
    composed='caf\u00e9-password'
    decomposed='cafe\u0301-password'
    assert encode_password(composed).value == encode_password(decomposed).value
    assert encode_password(composed).bin_index == encode_password(decomposed).bin_index

def test_case_sensitive():
    bins=build_bins(['CaseSensitive!'],capacity=8)
    assert psi_reference_check('CaseSensitive!',bins)
    assert not psi_reference_check('casesensitive!',bins)

def test_polynomial_root_and_nonroot():
    roots=[2,3,5,7,11,13,17,19]
    assert polynomial_value(7,roots)==0
    assert polynomial_value(23,roots)!=0

def test_bin_overflow_rejected():
    # Deterministically find nine strings mapping to same bin.
    by_bin={}
    i=0
    while True:
        s=f'overflow-{i}'
        b=encode_password(s).bin_index
        by_bin.setdefault(b,[]).append(s)
        if len(by_bin[b])==9: break
        i+=1
    with pytest.raises(OverflowError): build_bins(by_bin[b],capacity=8)

def test_invalid_password():
    with pytest.raises(ValueError): encode_password('')
