#!/usr/bin/env bash
set -euo pipefail
python -m pytest -q
python -m src.benchmark
python -m src.cli --password 'Synthetic-Breached-Password!'
python -m src.cli --password 'Definitely-Clean-Password!'
