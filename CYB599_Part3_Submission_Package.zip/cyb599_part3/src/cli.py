import argparse, json
from .psi_reference import build_bins, psi_reference_check

def main():
    p=argparse.ArgumentParser(description='CYB 599 privacy-preserving breach-check reference prototype')
    p.add_argument('--password',default='Synthetic-Breached-Password!')
    p.add_argument('--breach-file',help='UTF-8 text file, one synthetic breached password per line')
    a=p.parse_args()
    corpus=[x.strip() for x in open(a.breach_file,encoding='utf-8') if x.strip()] if a.breach_file else ['Synthetic-Breached-Password!','Example-Compromised-123']
    capacity=8
    while True:
        try: bins=build_bins(corpus,capacity=capacity); break
        except OverflowError: capacity+=8
    result=psi_reference_check(a.password,bins)
    print(json.dumps({'result':'compromised' if result else 'not found','backend':'plaintext reference model - NOT cryptographic BFV','database_entries':len(corpus),'bin_capacity':capacity},indent=2))
if __name__=='__main__': main()
