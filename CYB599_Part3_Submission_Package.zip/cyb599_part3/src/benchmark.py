from __future__ import annotations
import csv, json, os, platform, random, statistics, string, time
from pathlib import Path
from .psi_reference import build_bins, encode_password, psi_reference_check, plaintext_baseline, parameter_sets, estimated_ciphertext_bytes

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"

def make_passwords(n: int, seed: int = 2026) -> list[str]:
    rng = random.Random(seed + n)
    alphabet = string.ascii_letters + string.digits + "!@#$%"
    return ["Synthetic-" + "".join(rng.choice(alphabet) for _ in range(16)) for _ in range(n)]

def timed(fn, repeats=5):
    vals=[]
    for _ in range(repeats):
        t0=time.perf_counter(); fn(); vals.append((time.perf_counter()-t0)*1000)
    return statistics.median(vals)

def run():
    RESULTS.mkdir(exist_ok=True)
    rows=[]
    for n, capacity in [(1000,8),(10000,16),(100000,40)]:
        corpus=make_passwords(n)
        bins=build_bins(corpus, capacity=capacity, seed=599+n)
        breach=corpus[0]
        clean="Definitely-Not-In-Synthetic-Corpus-2026!"
        # Include end-to-end encoder+membership and plaintext baseline timings.
        psi_hit=timed(lambda: psi_reference_check(breach,bins))
        psi_miss=timed(lambda: psi_reference_check(clean,bins))
        baseline_set=set(corpus)
        base_hit=timed(lambda: breach in baseline_set)
        base_miss=timed(lambda: clean in baseline_set)
        assert psi_reference_check(breach,bins) is True
        assert psi_reference_check(clean,bins) is False
        assert plaintext_baseline(breach,baseline_set) is True
        assert plaintext_baseline(clean,baseline_set) is False
        for p in parameter_sets():
            up=3*estimated_ciphertext_bytes(p['N'],p['log2_q_budget'])
            response= p['alpha_100k'] * estimated_ciphertext_bytes(p['N'],60)
            rows.append({"dataset_size":n,"capacity_m":capacity,"parameter_set":p['name'],"N":p['N'],"t":p['t'],"log2_q_budget":p['log2_q_budget'],"reference_hit_ms":round(psi_hit,4),"reference_miss_ms":round(psi_miss,4),"plaintext_hit_ms":round(base_hit,4),"plaintext_miss_ms":round(base_miss,4),"estimated_upload_3ct_bytes":up,"estimated_download_100k_alpha_bytes":response,"measurement_type":"Python plaintext reference timing; ciphertext sizes analytical only"})
    out=RESULTS/'benchmark.csv'
    with out.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    meta={"python":platform.python_version(),"platform":platform.platform(),"cryptographic_backend":"NOT RUN - OpenFHE not installed in this build environment","timing_repeats":5,"timing_statistic":"median milliseconds","note":"Reference-model timings are not BFV timings. Ciphertext sizes are analytical estimates, not serialized OpenFHE ciphertext measurements."}
    (RESULTS/'environment.json').write_text(json.dumps(meta,indent=2))
    print(f"Wrote {out}")
    print(json.dumps(meta,indent=2))
if __name__=='__main__': run()
