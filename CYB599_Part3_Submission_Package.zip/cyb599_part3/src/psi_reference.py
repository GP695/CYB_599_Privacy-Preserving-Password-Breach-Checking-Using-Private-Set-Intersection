"""Functional reference model for CYB 599 Part 3.

IMPORTANT: This module is NOT cryptographic PSI and does NOT implement BFV.
It validates the encoder, binning, polynomial membership logic, and output
semantics from Part 2. Use OpenFHE BFV for production cryptographic evaluation.
"""
from __future__ import annotations
import hashlib, math, random, unicodedata
from dataclasses import dataclass
from typing import Iterable

N = 16_384
T = 549_756_174_337
D = 8
DOMAIN = b"CYB599-PSI-v1"

@dataclass(frozen=True)
class Encoded:
    bin_index: int
    value: int
    digest_hex: str

def encode_password(password: str) -> Encoded:
    if not isinstance(password, str) or not password:
        raise ValueError("password must be a non-empty string")
    normalized = unicodedata.normalize("NFC", password)
    digest = hashlib.sha256(DOMAIN + normalized.encode("utf-8")).digest()
    first14 = int.from_bytes(digest[:2], "big") >> 2
    next64 = int.from_bytes(digest[2:10], "big")
    value = 1 + (next64 % (T - 1))
    return Encoded(first14, value, digest.hex())

def build_bins(passwords: Iterable[str], *, capacity: int, seed: int = 599) -> list[list[int]]:
    if capacity <= 0 or capacity % D:
        raise ValueError("capacity must be a positive multiple of 8")
    rng = random.Random(seed)
    bins: list[list[int]] = [[] for _ in range(N)]
    for password in passwords:
        e = encode_password(password)
        bins[e.bin_index].append(e.value)
    for bucket in bins:
        if len(bucket) > capacity:
            raise OverflowError("bin overflow: rebuild with a new domain tag or larger capacity")
        rng.shuffle(bucket)
        bucket.extend(rng.randrange(1, T) for _ in range(capacity - len(bucket)))
    return bins

def polynomial_value(x: int, roots: Iterable[int], modulus: int = T) -> int:
    """Evaluate product (x-r) mod t; zero iff x equals one of the roots."""
    result = 1
    for root in roots:
        result = (result * (x - root)) % modulus
    return result

def psi_reference_check(password: str, bins: list[list[int]]) -> bool:
    """Return membership result using the Part-2 degree-8 root-polynomial logic.

    A False result means not found; True means compromised. This is plaintext
    reference computation, not encrypted evaluation.
    """
    e = encode_password(password)
    bucket = bins[e.bin_index]
    for start in range(0, len(bucket), D):
        if polynomial_value(e.value, bucket[start:start + D]) == 0:
            return True
    return False

def plaintext_baseline(password: str, breach_passwords: set[str]) -> bool:
    """Non-private baseline: direct local set membership on normalized strings."""
    normalized = unicodedata.normalize("NFC", password)
    normalized_set = {unicodedata.normalize("NFC", p) for p in breach_passwords}
    return normalized in normalized_set

def parameter_sets() -> list[dict]:
    # Both q budgets are below Part 2's 411-bit 128-bit-quantum ceiling
    # for N=16384. OpenFHE must generate/validate the actual modulus chain.
    return [
        {"name": "BFV-P1", "N": 16384, "t": T, "log2_q_budget": 300, "alpha_100k": 5},
        {"name": "BFV-P2", "N": 16384, "t": T, "log2_q_budget": 350, "alpha_100k": 5},
    ]

def estimated_ciphertext_bytes(N: int, log2_q: int) -> int:
    # Part-2 estimate: 2 * N * log2(q) bits per ciphertext (two components).
    return math.ceil(2 * N * log2_q / 8)
